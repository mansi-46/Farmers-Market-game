import java.util.*;

public class RouteCost {


  public static void main(String [] args) {
    Scanner inp = new Scanner(System.in);
    TreeSet<Link> links = new TreeSet<Link>();
    String color;
    String nameCopy="";

    try {
      String name = inp.nextLine();
      nameCopy = name;
      while(!name.equals("done")) {
        String separator[] = name.split(" ",4);
        if(separator.length < 3) {
//         throw new InputMismatchException();
          System.out.println("Invalid line: "+name);
          return;
        }
        City c1 = City.find(separator[0]);
        String distance = separator[1];
        try {
          Integer.parseInt(distance);
        } catch (NumberFormatException e) {
          System.out.println("Invalid line: "+name);
          return;
        }
        int length = Integer.parseInt(separator[1]);
        City c2 = City.find(separator[2]);
        if(separator.length == 4) {
          color = separator[3];
          if(!color.equals("green") && !color.equals("red")) {
//            throw new InputMismatchException();
            System.out.println("Invalid line: "+name);
            return;
          }
          else {
            Link l = new Link(c1,c2,length,color);
          }
        }
        name = inp.nextLine();
      }
    }
    catch (InputMismatchException e) {
      System.out.println("Invalid line: " + nameCopy);
    }
//      for (; !name.equals("done"); name = inp.next()) {
//        City c1 = City.find(name);
//        int length = inp.nextInt();
//        City c2 = City.find(inp.next());
//        Link l = new Link(c1, c2, length);
//      }

    try {
      String name = inp.nextLine();
      nameCopy = name;
      while (!name.equals("done")) {
        String separator[] = name.split(" ", 3);
        if (separator.length < 2 || separator.length > 3) {
//          throw new InputMismatchException();
          System.out.println("Invalid line: "+ name);
          return;
        }
        City c1 = City.find(separator[0]);
        City c2 = City.find(separator[1]);
        String colour = null;
        if(separator.length == 3) {
          colour = separator[2];
          if (!colour.equals("green") && !(colour.equals("red"))) {
//          throw new InputMismatchException();
            System.out.println("Invalid line: "+ name);
            return;
          }
        }
        c1.makeTree(colour);
        if (!c1.getLinksTo(c2, links, colour)) {
          System.out.println("Error: Route not found! " + separator[0]);
          return;
        }
        name = inp.nextLine();
      }
    }
    catch (InputMismatchException e) {
      System.out.println("Invalid Input: " + nameCopy);
    }

//    for (String name = inp.next(); !name.equals("done"); name = inp.next()) {
//      City c = City.find(name);
//      c.makeTree();
//      if (!c.getLinksTo(City.find(inp.next()), links,color)) {
//        System.out.println("Error: Route not found! " + name);
//        return;
//      }
//    }

    int total = 0;
    System.out.println("The rail network consists of:");
    for (Link l : links) {
      System.out.println("  " + l);
      total += l.getLength();
    }
    System.out.println("The total cost is: " + total);
  }
}
